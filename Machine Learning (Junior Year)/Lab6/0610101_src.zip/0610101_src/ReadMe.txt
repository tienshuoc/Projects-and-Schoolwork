cell 3: set dataroot to data path of training samples
call 16: sepcify folder path to save generated images to

run all cells to train samples and then generate and save 50000 logos to desired folder location